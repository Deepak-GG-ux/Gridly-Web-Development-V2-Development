/**
 * scripts/data/pricing.js
 *
 * Single source of truth for the Services & Pricing page.
 *
 * Everything the page renders — plan names, prices, feature lists, the
 * comparison matrix, the process steps, the FAQ and the image manifest —
 * lives here. Change a price or a feature in this file and every place it
 * appears updates. No pricing string should ever be written into markup.
 *
 * Prices are INR and are *starting* figures, not quotes. The page must
 * always render them with `plan.priceLabel` so the "Starting at" framing
 * survives any future edit to the number.
 */

/* --------------------------------------------------------------------------
 * Currency
 * ----------------------------------------------------------------------- */

export const currency = {
  code: 'INR',
  symbol: '₹',
  /** Indian digit grouping: 1,23,456 rather than 123,456. */
  format(amount) {
    return new Intl.NumberFormat('en-IN', {
      style: 'currency',
      currency: 'INR',
      maximumFractionDigits: 0,
    }).format(amount);
  },
};

/* --------------------------------------------------------------------------
 * Packages
 *
 * `price: null` means the plan is quoted rather than listed. The page reads
 * `priceLabel` / `priceNote`, never `price` directly.
 * ----------------------------------------------------------------------- */

export const pricingPlans = [
  {
    id: 'starter',
    name: 'Starter',
    price: 4999,
    priceLabel: 'Starting at ₹4,999',
    priceNote: 'One-off project fee',
    tagline: 'A clear, fast online presence.',
    suitableFor:
      'Personal sites, portfolios and small local businesses that need to be findable and credible.',
    timeline: '1–2 weeks',
    popular: false,
    features: [
      'Up to 3 pages',
      'Responsive design',
      'Mobile optimisation',
      'Contact section',
      'Basic SEO setup',
      'Social media links',
      'Basic performance optimisation',
      'Deployment assistance',
    ],
    cta: { label: 'Start a project', href: '/contact.html' },
  },
  {
    id: 'business',
    name: 'Business',
    price: 9999,
    priceLabel: 'Starting at ₹9,999',
    priceNote: 'One-off project fee',
    tagline: 'A complete professional website.',
    suitableFor:
      'Small businesses, agencies, independent professionals and local brands.',
    timeline: '2–4 weeks',
    popular: true,
    badge: 'Most popular',
    features: [
      'Up to 6–8 pages',
      'Custom responsive design',
      'Contact and enquiry form',
      'WhatsApp call-to-action',
      'Basic SEO setup',
      'Google Maps integration',
      'Social media integration',
      'Speed optimisation',
      'Deployment support',
      'Content structure guidance',
    ],
    cta: { label: 'Start a project', href: '/contact.html' },
  },
  {
    id: 'growth',
    name: 'Growth',
    price: 19999,
    priceLabel: 'Starting at ₹19,999',
    priceNote: 'One-off project fee',
    tagline: 'Sell, capture leads and measure what happens.',
    suitableFor:
      'Growing businesses and online stores that need to transact, not just inform.',
    timeline: '4–6 weeks',
    popular: false,
    features: [
      'Up to 12 pages',
      'E-commerce functionality',
      'Product and catalogue sections',
      'Forms and lead capture',
      'Advanced responsive design',
      'Analytics integration',
      'SEO setup',
      'Performance optimisation',
      'Deployment support',
      'Third-party integration support',
    ],
    cta: { label: 'Start a project', href: '/contact.html' },
  },
  {
    id: 'custom',
    name: 'Custom',
    price: 34999,
    priceLabel: 'From ₹34,999',
    priceNote: "Let's discuss your requirements",
    tagline: 'Built around how your business actually works.',
    suitableFor:
      'Businesses that need custom functionality, user accounts or a system rather than a site.',
    timeline: 'Scoped per project',
    popular: false,
    features: [
      'Custom UI/UX',
      'Advanced web functionality',
      'Database integration',
      'Custom dashboards',
      'API integrations',
      'Authentication and user systems where required',
      'Advanced forms and workflows',
      'Deployment assistance',
      'Project-specific technical architecture',
    ],
    cta: { label: 'Discuss your project', href: '/contact.html' },
  },
];

/* --------------------------------------------------------------------------
 * Comparison matrix
 *
 * `values` is keyed by plan id so a column can never drift out of order.
 * A value is either a string (rendered as text), `true` (tick) or
 * `false` (dash). The page must render `false` as an em dash with an
 * `aria-label` of "Not included" — never as an empty cell.
 * ----------------------------------------------------------------------- */

export const comparisonRows = [
  {
    label: 'Pages included',
    values: { starter: 'Up to 3', business: '6–8', growth: 'Up to 12', custom: 'Unlimited' },
  },
  {
    label: 'Responsive design',
    values: { starter: true, business: true, growth: true, custom: true },
  },
  {
    label: 'Mobile optimisation',
    values: { starter: true, business: true, growth: true, custom: true },
  },
  {
    label: 'Contact form',
    values: { starter: 'Basic', business: true, growth: true, custom: 'Advanced' },
  },
  {
    label: 'SEO setup',
    values: { starter: 'Basic', business: 'Basic', growth: 'Full', custom: 'Full' },
  },
  {
    label: 'Google Maps',
    values: { starter: false, business: true, growth: true, custom: true },
  },
  {
    label: 'Social integration',
    values: { starter: 'Links only', business: true, growth: true, custom: true },
  },
  {
    label: 'Analytics',
    values: { starter: false, business: false, growth: true, custom: true },
  },
  {
    label: 'E-commerce',
    values: { starter: false, business: false, growth: true, custom: true },
  },
  {
    label: 'Database',
    values: { starter: false, business: false, growth: false, custom: true },
  },
  {
    label: 'API integration',
    values: { starter: false, business: false, growth: 'Limited', custom: true },
  },
  {
    label: 'Custom functionality',
    values: { starter: false, business: false, growth: 'Limited', custom: true },
  },
  {
    label: 'Deployment assistance',
    values: { starter: true, business: true, growth: true, custom: true },
  },
  {
    label: 'Maintenance options',
    values: { starter: 'Optional', business: 'Optional', growth: 'Optional', custom: 'Included 30 days' },
  },
  {
    label: 'Typical timeline',
    values: { starter: '1–2 weeks', business: '2–4 weeks', growth: '4–6 weeks', custom: 'Scoped' },
  },
];

/* --------------------------------------------------------------------------
 * Services
 *
 * `image` is a key into `imageManifest` below, not a path. That keeps
 * licensing and file paths in one place.
 * ----------------------------------------------------------------------- */

export const servicesData = [
  {
    id: 'landing-page',
    name: 'Landing Page',
    summary: 'One page built to do one job — explain the offer and get the enquiry.',
    startingAt: 4999,
    timeline: '3–7 days',
    suitableFor: 'Campaigns, single products, event sign-ups.',
    features: [
      'Single-page responsive build',
      'Enquiry or sign-up form',
      'Performance and SEO basics',
      'Deployment assistance',
    ],
    cta: { label: 'Enquire', href: '/contact.html' },
  },
  {
    id: 'business-website',
    name: 'Business Website',
    summary: 'The pages a business is expected to have, written and built properly.',
    startingAt: 9999,
    timeline: '2–4 weeks',
    suitableFor: 'Established local businesses and professional services.',
    features: [
      'Custom responsive design',
      'Six to eight pages',
      'Enquiry form and maps',
      'SEO and speed optimisation',
    ],
    cta: { label: 'Enquire', href: '/contact.html' },
  },
  {
    id: 'professional-website',
    name: 'Professional Website',
    summary: 'A larger site with structured content, richer navigation and room to grow.',
    startingAt: 14999,
    timeline: '3–5 weeks',
    suitableFor: 'Agencies, firms and multi-service businesses.',
    features: [
      'Content architecture',
      'Reusable component library',
      'Editorial or resource section',
      'Analytics and SEO setup',
    ],
    cta: { label: 'Enquire', href: '/contact.html' },
  },
  {
    id: 'ecommerce',
    name: 'E-commerce Website',
    summary: 'Catalogue, cart and checkout, built around your actual fulfilment process.',
    startingAt: 19999,
    timeline: '4–6 weeks',
    suitableFor: 'Retailers moving online and existing stores outgrowing a marketplace.',
    features: [
      'Product catalogue and search',
      'Cart and checkout flow',
      'Payment gateway integration',
      'Order and inventory structure',
    ],
    image: 'ecommerce',
    cta: { label: 'Enquire', href: '/contact.html' },
  },
  {
    id: 'web-application',
    name: 'Custom Web Application',
    summary: 'Software with a login, a database and workflows specific to your business.',
    startingAt: 34999,
    timeline: 'Scoped per project',
    suitableFor: 'Operations that are currently running on spreadsheets.',
    features: [
      'Custom data model',
      'Authentication and roles',
      'Dashboards and reporting',
      'API integrations',
    ],
    image: 'webApplication',
    cta: { label: 'Discuss requirements', href: '/contact.html' },
  },
  {
    id: 'redesign',
    name: 'Website Redesign',
    summary: 'Keep what works on your current site, fix what does not, and rebuild the rest.',
    startingAt: 12999,
    timeline: '2–5 weeks',
    suitableFor: 'Sites that look dated, load slowly or fail on mobile.',
    features: [
      'Audit of the existing site',
      'Content migration',
      'Rebuilt responsive front end',
      'Redirect map so rankings survive',
    ],
    image: 'uiUx',
    cta: { label: 'Request an audit', href: '/contact.html' },
  },
  {
    id: 'seo-growth',
    name: 'SEO & Digital Growth',
    summary: 'Technical SEO and content structure so the site can actually be found.',
    startingAt: 7999,
    timeline: 'Ongoing, monthly',
    suitableFor: 'Sites with traffic problems rather than design problems.',
    features: [
      'Technical SEO audit',
      'On-page optimisation',
      'Analytics and Search Console setup',
      'Monthly reporting',
    ],
    image: 'seoAnalytics',
    cta: { label: 'Enquire', href: '/contact.html' },
  },
  {
    id: 'maintenance',
    name: 'Website Maintenance',
    summary: 'Updates, fixes and monitoring so the site does not quietly rot after launch.',
    startingAt: 2499,
    timeline: 'Monthly retainer',
    suitableFor: 'Any live site without someone looking after it.',
    features: [
      'Content and copy updates',
      'Dependency and security updates',
      'Uptime and performance monitoring',
      'Priority fixes',
    ],
    cta: { label: 'Enquire', href: '/contact.html' },
  },
];

/* --------------------------------------------------------------------------
 * How it works
 * ----------------------------------------------------------------------- */

export const processSteps = [
  {
    step: '01',
    title: 'Tell us what you need',
    body: 'Send the brief, or a rough description. We ask what the site has to achieve and who it is for before talking about pages.',
    icon: 'message',
  },
  {
    step: '02',
    title: 'Plan and design',
    body: 'Scope, sitemap and design direction. You see and approve the layout before anything is built.',
    icon: 'layout',
  },
  {
    step: '03',
    title: 'Build and test',
    body: 'The site is built, then tested across browsers and screen sizes, including real mobile widths.',
    icon: 'code',
  },
  {
    step: '04',
    title: 'Launch and support',
    body: 'We deploy, hand over access, and stay available for fixes and changes after go-live.',
    icon: 'rocket',
  },
];

/* --------------------------------------------------------------------------
 * FAQ (scoped to pricing — keep separate from scripts/data/faq.js)
 * ----------------------------------------------------------------------- */

export const pricingFaq = [
  {
    q: 'How do I get started?',
    a: 'Send an enquiry with a short description of the project. We reply to project enquiries within two working days with questions, an approach and a scope.',
  },
  {
    q: 'How long does a website usually take?',
    a: 'A landing page takes a few days. A business website is typically two to four weeks. Larger builds are scoped individually. The main variable is how quickly content and feedback come back.',
  },
  {
    q: 'Can you redesign my existing website?',
    a: 'Yes. We audit the current site first, keep the pages and rankings that are working, and put a redirect map in place so search traffic survives the move.',
  },
  {
    q: 'Do you build mobile-friendly websites?',
    a: 'Every build is responsive and tested down to 320px. Mobile is not an afterthought — most of the traffic arrives there.',
  },
  {
    q: 'Can you add e-commerce functionality?',
    a: 'Yes, from the Growth package upward. That covers catalogue, cart, checkout and payment gateway integration.',
  },
  {
    q: 'Can you help with SEO?',
    a: 'Technical SEO is included in every package. Ongoing content and growth work is available as a separate monthly engagement.',
  },
  {
    q: 'Can you maintain my website after launch?',
    a: 'Yes. Maintenance is a monthly retainer covering content updates, security updates, monitoring and priority fixes.',
  },
  {
    q: 'Can I request a custom website?',
    a: 'Yes. If the packages do not fit, the Custom track is scoped from your requirements rather than from a feature list.',
  },
  {
    q: 'What information do you need before starting?',
    a: 'What the site is for, who it is for, any existing brand assets, and the content you already have. We can help produce what is missing.',
  },
];

/* --------------------------------------------------------------------------
 * Image manifest
 *
 * Provenance lives here so licensing is auditable. Fill `src`, `source`
 * and `credit` when the file is downloaded into /assets/img/. Never point
 * `src` at a remote host — download the file first.
 *
 * Licence rule: Pexels, Unsplash (free tier only, not Unsplash+) or
 * Wikimedia Commons where the specific licence permits reuse.
 * ----------------------------------------------------------------------- */

export const imageManifest = {
  webTeam: {
    src: '/assets/img/web-development-team.jpg',
    alt: 'Two developers reviewing a responsive website layout on a laptop',
    width: 1600,
    height: 1067,
    source: '',
    credit: '',
    licence: '',
  },
  uiUx: {
    src: '/assets/img/ui-ux-design.jpg',
    alt: 'Interface wireframes and screen layouts laid out on a desk',
    width: 1600,
    height: 1067,
    source: '',
    credit: '',
    licence: '',
  },
  ecommerce: {
    src: '/assets/img/ecommerce-development.jpg',
    alt: 'Online store product page open on a laptop beside packed orders',
    width: 1600,
    height: 1067,
    source: '',
    credit: '',
    licence: '',
  },
  seoAnalytics: {
    src: '/assets/img/seo-analytics.jpg',
    alt: 'Analytics dashboard showing website traffic and search performance',
    width: 1600,
    height: 1067,
    source: '',
    credit: '',
    licence: '',
  },
  webApplication: {
    src: '/assets/img/web-application.jpg',
    alt: 'Custom admin dashboard displaying records and summary charts',
    width: 1600,
    height: 1067,
    source: '',
    credit: '',
    licence: '',
  },
  workspace: {
    src: '/assets/img/website-workspace.jpg',
    alt: 'Quiet studio workspace with a monitor showing a website in progress',
    width: 1600,
    height: 1067,
    source: '',
    credit: '',
    licence: '',
  },
};

/* --------------------------------------------------------------------------
 * Helpers
 * ----------------------------------------------------------------------- */

/** Look up a plan by id. Returns undefined if the id is unknown. */
export function findPlan(id) {
  if (typeof id !== 'string') return undefined;
  const key = id.trim().toLowerCase();
  return pricingPlans.find((plan) => plan.id === key);
}

/** Plan ids in display order — use this to build comparison columns. */
export const planOrder = pricingPlans.map((plan) => plan.id);

/** The plan marked as popular, or null. Used for the card badge. */
export const popularPlanId = (pricingPlans.find((plan) => plan.popular) || {}).id || null;
